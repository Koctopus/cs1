$("#role_check").click(function check(event) {
	　　　　alert($("#rolecheck").val());
    });